# output folder
This folder holds simulation output data.
Don't push the output files to the repository.